#!/usr/bin/env python3

# Created by Gabriel A
# Created on Dec 2020
# This is a program that predicts if you'll be able to marry


def main():
    # this function uses a try statement

    # input
    print("Will your girlfriend's grandma allow you to marry her?")

    try:
        age = int(input("Enter your age: "))
        print("")
        # process & output
        if age >= 25 and age < 40:
            print("Looks like she will allow you two to marry!")
        elif age > 40 or age < 25:
            print("No chance :(")
            print("You have to be between 25-40 years old!")
        else:
            print("ERROR: INVALID INTEGER")
    except ValueError:
        print("")
        print("ERROR: ENTERED INVALID CHARACTER(S)")


if __name__ == "__main__":
    main()
